function initDarkModeToggle() {
    const darkModeToggle = document.getElementById("darkModeToggle");

    if (darkModeToggle) {
        // Remove old event listeners by cloning the element
        const newToggle = darkModeToggle.cloneNode(true);
        darkModeToggle.parentNode.replaceChild(newToggle, darkModeToggle);

        // Add new event listener
        newToggle.addEventListener("click", function () {
            if (document.documentElement.classList.contains("dark")) {
                document.documentElement.classList.remove("dark");
                localStorage.setItem("theme", "light");
            } else {
                document.documentElement.classList.add("dark");
                localStorage.setItem("theme", "dark");
            }

            // Trigger chart recreation if on dashboard
            if (typeof window.createCharts === "function") {
                setTimeout(() => window.createCharts(), 100);
            }

            // Dispatch custom event for other components
            window.dispatchEvent(new Event("dark-mode-toggled"));
        });
    }
}

document.addEventListener("DOMContentLoaded", initDarkModeToggle);
document.addEventListener("livewire:navigated", initDarkModeToggle);
